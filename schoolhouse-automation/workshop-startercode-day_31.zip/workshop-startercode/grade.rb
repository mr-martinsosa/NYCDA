class Grade
  attr_accessor :subject, :score

  def initialize(subject, score)
    @subject = subject,
    @score = score
  end

end
